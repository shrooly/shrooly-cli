from setuptools import setup, find_packages

setup(
    name='shrooly_cli',
    version='0.1',
    url="https://github.com/shrooly/shrooly-cli",
    author='Adam Lipecz',
    author_email='developer@shrooly.com',
    packages=find_packages(),
    install_requires=[
        'sys',
        'argparse',
        'queue',
        'json',
        're',
        'csv',
        'time',
        'logging',
        'colorlog',
        'datetime',
        'pathlib',
        'serial'
    ],
)