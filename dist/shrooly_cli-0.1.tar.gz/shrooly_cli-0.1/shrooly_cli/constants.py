# DTR and RTS pin settings
LOW = True
HIGH = False

MINIMAL_EN_LOW_DELAY = 0.005